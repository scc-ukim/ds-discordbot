![SCC UKIM Helper Banner](https://github.com/scc-ukim/ds-discordbot/blob/main/assets/banner-ds-discord.png?raw=true)

## SCC UKIM Helper | Discord Bot

A simple discord bot to help moderation process.

----

If you are part of the **development team** please read [todo](./todo.md) or check the `development-chat` on `discord` and `env-data`
